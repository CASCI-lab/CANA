args = commandArgs(T)

require(parallel)

source('SimNKEnsembles.R')

N = 100

K = 12

MinP = args[1]
MaxP = args[2]
PartNum = as.integer(args[3])
NumParts = as.integer(args[4])
KeffType = args[5]
NumCores = as.integer(args[6])

NumSampleNets = 200
TotalNumInitStates = 1000
NumFlips = c(1, 2, 4, 6, 10)
NumSteps = 10
RecordSteps = c(0, 1, 2, 5, 10)

# NumSampleNets = 2
# TotalNumInitStates = 10
# NumFlips = c(1, 2, 4, 6, 10)
# NumSteps = 10
# RecordSteps = c(0, 1, 2, 5, 10)

load(paste('./Data/SimDataK',K,'P',MinP,'to',MaxP,KeffType,'_Norm.Rdata',sep=''))  # loads into 'SimData'

TotalSize = length(SimData)

PartSize = floor(TotalSize / NumParts)

StIdx = ((PartNum - 1) * PartSize) + 1
EndIdx = StIdx + PartSize - 1

ResidPartSize = TotalSize %% NumParts

if (PartNum == NumParts) EndIdx = EndIdx + ResidPartSize  # Last part

NumSamples = EndIdx - StIdx + 1

q = floor(NumSamples / NumCores)
r = NumSamples %% NumCores
s = ifelse(r > 0, 1, 0)
SampleSizes = c(rep(NumCores, q), rep(r, s))  # sum(SampleSizes) = NumSamples

nd = StIdx - 1

AllNetDynStatsAllNets = list()

for (i in 1 : length(SampleSizes)) {
	
	NumSamps = SampleSizes[i]
	
	st = nd + 1
	nd = st + NumSamps - 1
	
	print(c(st, nd))
	
	DynStatsAllNets = mclapply(SimData[st : nd], SimNKEnsembles, N, K, NumSampleNets, TotalNumInitStates,
														NumFlips, NumSteps, RecordSteps, mc.cores = NumCores)
	
	AllNetDynStatsAllNets = append(AllNetDynStatsAllNets, DynStatsAllNets)
	
	save(AllNetDynStatsAllNets, file = paste('./Data/SimResultsK',K,'P',MinP,'to',MaxP,KeffType,
																		'_Norm','_Part_',PartNum,'.Rdata',sep=''))

}

# AllNetDynStats = SimNKEnsembles(SimData[[41]], N, K, 5, 10, c(1,2), 2, c(0,2))

# print(sapply(AllNetDynStats[[1]], function(s) s$PerturbStats[1, ]))





