#!/bin/bash

NumParts=3
KeffType="K_e_p"

for ((i=1; i<=NumParts; i+=1))
do
	qsub Run_SimNKEnsemblesK12.pbs -v PartNum=$i,NumParts=$NumParts,KeffType=$KeffType
done