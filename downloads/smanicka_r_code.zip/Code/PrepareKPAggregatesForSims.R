source('ComputeDataAggregates.R')

K = 3  

P_resol = 0.01

MinP = 0.0    
MaxP = 0.5  

if (K == 2 | K == 3 | K == 4 | K == 6) PartNums = 1   
if (K == 8) PartNums = 1 : 4     

if (K == 2 | K == 3 | K == 4) SetNums = 1  
if (K == 6) SetNums = 7  
if (K == 8) SetNums = c(10, 10, 11, 2)      

AllFuncsAllSets = c()

for (PartNum in PartNums) {
	
	for (SetNum in 1 : SetNums[PartNum]) {

		rm(AllKeffData)
	
		fname = paste('./Data/K',K,'FuncsKeffKsymmKeffGen_Part',PartNum,'_Set',SetNum,'.Rdata',sep='')
		load(fname)  # loads into 'AllKeffData'
		
		AllFuncsAllSets = cbind(AllFuncsAllSets, sapply(AllKeffData, function(r) r$func))
			
	}

}

AllKeffDataAllSets = c()

for (PartNum in PartNums) {
	
	for (SetNum in 1 : SetNums[PartNum]) {

		rm(AllKeffData)
	
		fname = paste('./Data/K',K,'BiasKeffKsymmKeffGen_Part',PartNum,'_Set',SetNum,'.Rdata',sep='')
		load(fname)  # loads into 'AllKeffData'
		
		AllKeffDataAllSets = cbind(AllKeffDataAllSets, AllKeffData)
	
	}

}

# Notes on 'AllKeffData':
# It's a matrix -
# 1st row = P (values in the interval [0.0, 0.5]; for K = 4, intvl is [0.0, 1.0])
# 2nd row = K_e
# 3rd row = K_s
# 4th row = K_e_gen

P_min = 0.0
P_max = 0.5

Ke_min = 0.0
Ke_max = 1.0

Data = AllKeffDataAllSets

PData = Data[1, ]
Data[2, ] = Data[2, ] / K
Data[3, ] = Data[3, ] / K
Data[4, ] = Data[4, ] / K

PIntvls = seq(0, 1, P_resol)

PLabels = cut(PData, breaks = PIntvls, labels = F)

SimData = list()
SimDataIdx = 1

for (s in unique(PLabels)) {
	
	SegDataColIds = which(PLabels == s)
	
	DataSubset = matrix(Data[ , SegDataColIds], nrow = nrow(Data))
	
	Funcs = matrix(AllFuncsAllSets[ , SegDataColIds], nrow = 2 ^ K)
	
	SimData[[SimDataIdx]] = list(Funcs = Funcs, P = DataSubset[1, ], K_e = DataSubset[2, ],
												   K_s = DataSubset[3, ], K_e_p = DataSubset[4, ])
			
	SimDataIdx = SimDataIdx + 1
			
}


fname = paste('./Data/SimDataK',K,'P',MinP,'to',MaxP,'Norm.Rdata',sep='')

save(SimData, file = fname)

## Sanity check
# i = sample(length(SimData), 1)
# print(max(SimData[[i]]$K_e) - min(SimData[[i]]$K_e))
# print(max(SimData[[i]]$K_e_p) - min(SimData[[i]]$K_e_p))

























