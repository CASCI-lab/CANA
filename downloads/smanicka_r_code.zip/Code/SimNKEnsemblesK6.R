args = commandArgs(T)

require(parallel)

source('SimNKEnsembles.R')
source('ComputePerturbationStats.R')

N = 100

K = 6

MinP = 0
MaxP = 0.5

NumCores = 1

NumSampleNets = 500
TotalNumInitStates = 1000
NumFlips = c(1, 2, 4, 6, 10)
NumSteps = 10
RecordSteps = c(0, 1, 2, 5, 10)

load(paste('./Data/SimDataK',K,'P',MinP,'to',MaxP,'Norm.Rdata',sep=''))  # loads into 'SimData'

AllNetDynStatsAllNets = mclapply(SimData, SimNKEnsembles, N, K, NumSampleNets, TotalNumInitStates,
														NumFlips, NumSteps, RecordSteps, mc.cores = NumCores)

save(AllNetDynStatsAllNets, file = paste('./Data/SimResultsK',K,'P',MinP,'to',MaxP,'Norm.Rdata',sep=''))

# AllNetDynStats = SimNKEnsembles(SimData[[41]], N, K, 5, 10, c(1,2), 2, c(0,2))

# print(sapply(AllNetDynStats[[1]], function(s) s$PerturbStats[1, ]))








