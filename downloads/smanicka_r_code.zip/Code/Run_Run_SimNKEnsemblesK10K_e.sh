#!/bin/bash

NumParts=3

for ((i=1; i<=NumParts; i+=1))
do
	qsub RunSimNKEnsemblesK10K_e.pbs -v PartNum=$i,NumParts=$NumParts
done