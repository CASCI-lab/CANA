require(BoolNet)

# Returns a matrix of the following dimensions:
# nrow = (length(NumFlips) * 9) 
# ncol = length(RecordSteps)
# The number 9 in the nrow above is the net length of a mean, sd values (2) and boxplots.stats(5 + 2)

ComputePerturbationStats <- function(Net, TotalNumInitStates, NumFlips, NumSteps, RecordSteps, NumCores = 1) {

	PerturbStatesCompTrajectories <- function(idx, FlipSize, NumSteps, N) {
		
		st = sample(c(0, 1), N, replace = T)
		
		flippedSt = st
		flipPos = sample(1 : N, FlipSize, replace = F)
		flippedSt[flipPos] = (flippedSt[flipPos] + 1) %% 2
		
		HammDistSeries = c(FlipSize, rep(0, NumSteps))
		
		for (step in 1 : NumSteps) {

			nst = stateTransition(Net, st)
			nstFlipped = stateTransition(Net, flippedSt)
						
			st = nst
			flippedSt = nstFlipped
			
			HammDistSeries[step + 1] = sum(abs(st - flippedSt))
			
		}
		
		return(HammDistSeries)
		
	}
	
	N = length(Net$genes)  # number of nodes in the net
	
	AllHammDistStats = c()
	
	numInitStates = ceiling(TotalNumInitStates / length(NumFlips))
	
	for (FlipSize in NumFlips) {
		
		HammDistSeries = mclapply(1 : numInitStates, PerturbStatesCompTrajectories, FlipSize, 
														NumSteps, N, mc.cores = NumCores)
		
		HammDistSeries = matrix(unlist(HammDistSeries), nrow = NumSteps + 1)
			
		HammDistSeries = HammDistSeries[RecordSteps + 1, ]
	
		HammDistStats = apply(HammDistSeries, 1, function(v) {
			
			bs = boxplot.stats(v)
			
			Freqs = hist(v, breaks = 0 : (N+1), plot=F)$counts
			
			# Mode = which(Freqs == max(Freqs))[1] - 1
			# Mode_0 = Freqs[1]

			return(c(mean(v), sd(v), bs$stats, bs$conf))  # length = 2 + 5 + 2 = 9
		
		})  # returns a column-wise matrix (nrow = 9)
				
		AllHammDistStats = rbind(AllHammDistStats, HammDistStats)
		
	}
	
	return(AllHammDistStats)
	
}

# N = 100
# K = 4
# P = 0.5
# Net = generateRandomNKNetwork(N, K, topology="fixed", linkage="uniform",functionGeneration="biased", 
																# noIrrelevantGenes=F, zeroBias=P)

# res = ComputePerturbationStats(Net, 500, c(1,2,4,6,10), 10, c(0,1,2,5,10))










