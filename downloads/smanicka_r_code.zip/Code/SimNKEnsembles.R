require(BoolNet)
require(igraph)

source('ComputePerturbationStats.R')

# Returns a list of length NumSampleNets with the following subitems:
# scalars: $K, $P, $K_e
# matrix: $PerturbStats whose nrow = (NumFlips * 9) and ncol = length(RecordSteps)
# The number 9 in the nrow above is the net length of a mean, sd values (2) and boxplots.stats(5 + 2)

SimNKEnsembles <- function(FuncSetData, N, K, NumSampleNets, TotalNumInitStates,
														NumFlips, NumSteps, RecordSteps) {

	NumFuncs = ncol(FuncSetData$Funcs)
	
	AllNetDynStats = list()
	
	for (s in 1 : NumSampleNets) {
	
		NetConnected = F
		
		while (!NetConnected) {
			
			Net = generateRandomNKNetwork(N, K, topology = "fixed", linkage = "uniform", 
							functionGeneration = "uniform", noIrrelevantGenes = F, simplify=F)
							
			# Check if Net is connected
			
			NetAdjacency = matrix(0,N,N)
			
			# > A = matrix(c(0,1,0,0,0,1,1,0,0),3,3,byrow=T)
			# > graph.adjacency(A)
			# IGRAPH D--- 3 3 -- 
			# + edges:
			# [1] 1->2 2->3 3->1
			
			for (n in 1 : N) {
				
				inputs = Net$interactions[n][[1]]$input
				NetAdjacency[inputs, n] = 1    # [inputs, n], not [n, inputs]; see example above
				
			}
			
			g = graph.adjacency(NetAdjacency, mode = 'directed')
			
			NetConnected = is.connected(g, mode = 'weak')
			
			if (! NetConnected) next
			
			# Replace self-loops with a random non-self input
			
			for (n in 1 : N) {
				
				inputs = Net$interactions[n][[1]]$input
				
				while (n %in% inputs) inputs[inputs == n] = sample(N, 1)
				
				Net$interactions[n][[1]]$input = inputs
				
			}
			
			if (NumFuncs < N) rpl = T else rpl = F
			
			FuncsIdx = sample(NumFuncs, N, replace = rpl)
			
			for (n in 1 : N) Net$interactions[n][[1]]$func = FuncSetData$Funcs[ , FuncsIdx[n]]
	
		}  # at this point a Net is constructed
		
		NetDynStats = ComputePerturbationStats(Net, TotalNumInitStates, NumFlips, NumSteps, RecordSteps)
		
		MeanP = mean(FuncSetData$P[FuncsIdx])
		
		MeanKe = mean(FuncSetData$K_e[FuncsIdx]) 	
		
		MeanKep = mean(FuncSetData$K_e_p[FuncsIdx]) 	
		
		AllNetDynStats[[s]] = list(K = K, P = MeanP, K_e = MeanKe, K_e_p = MeanKep, 
													PerturbStats = NetDynStats)
				
	}  # at this point all NumSampleNets have been simulated
	
	return(AllNetDynStats)

}













