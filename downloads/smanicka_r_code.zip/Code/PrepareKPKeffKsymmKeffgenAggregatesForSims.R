source('ComputeDataAggregates.R')

dir = './Data/K12/'

K = 12  # CHANGE

Control = 'K_e_p'   # CHANGE  # partition by K_e or K_e_p

P_resol = 0.025  # 0.01, 0.025
if (K == 12) Ke_resol = 0.04 else if (K == 10) Ke_resol = 0.05 else Ke_resol = 0.08

MinP = 0.0                           # CHANGE
MaxP = 0.26   # 0.27, 0.26  # CHANGE

if (K == 2 | K == 3 | K == 4 | K == 6) PartNums = 1   
if (K == 8) PartNums = 1 : 4     
if (K == 10) PartNums = 1 : 2  
if (K == 12) PartNums = 1 : 6   

if (K == 2 | K == 3 | K == 4) SetNums = 1  
if (K == 6) SetNums = 7  
if (K == 8) SetNums = c(10, 10, 11, 2)      
if (K == 10) SetNums = c(27, 27)      
if (K == 12) SetNums = rep(11, 6)      

AllFuncsAllSets = c()

for (PartNum in PartNums) {
	
	for (SetNum in 1 : SetNums[PartNum]) {
		
		print(c(PartNum, SetNum))

		rm(AllKeffData)
	
		fname = paste(dir,'K',K,'FuncsKeffKsymmKeffGen_Part',PartNum,'_Set',SetNum,'.Rdata',sep='')
		load(fname)  # loads into 'AllKeffData'
		
		AllFuncsAllSets = cbind(AllFuncsAllSets, sapply(AllKeffData, function(r) r$func))
			
	}

}

print('Loaded funcs')

if (K == 12) {
	
	for (PartNum in 1 : 39) {
		
		print(c(PartNum, 12))
	
		rm(AllKeffData)
	
		fname = paste(dir,'K',K,'FuncsKeffKsymmKeffGen_Part',PartNum,'_Set12.Rdata',sep='')
		load(fname)  # loads into 'AllKeffData'
		
		AllFuncsAllSets = cbind(AllFuncsAllSets, sapply(AllKeffData, function(r) r$func))
				
	}
	
}

print('Loaded funcs')

AllKeffDataAllSets = c()

for (PartNum in PartNums) {
	
	for (SetNum in 1 : SetNums[PartNum]) {
		
		print(c(PartNum, SetNum))

		rm(AllKeffData)
	
		fname = paste(dir,'K',K,'BiasKeffKsymmKeffGen_Part',PartNum,'_Set',SetNum,'.Rdata',sep='')
		load(fname)  # loads into 'AllKeffData'
		
		AllKeffDataAllSets = cbind(AllKeffDataAllSets, AllKeffData)
	
	}

}

print('Loaded bias')

if (K == 12) {
	
	for (PartNum in 1 : 39) {
		
		print(c(PartNum, 12))
	
		rm(AllKeffData)
	
		fname = paste(dir,'K',K,'BiasKeffKsymmKeffGen_Part',PartNum,'_Set12.Rdata',sep='')
		load(fname)  # loads into 'AllKeffData'
		
		AllKeffDataAllSets = cbind(AllKeffDataAllSets, AllKeffData)
		
	}
	
}

print('Loaded bias')

# Notes on 'AllKeffData':
# It's a matrix -
# 1st row = P (values in the interval [0.0, 0.5]; for K = 4, intvl is [0.0, 1.0])
# 2nd row = K_e
# 3rd row = K_s
# 4th row = K_e_gen

P_min = 0.0
P_max = 0.5

Ke_min = 0.0
Ke_max = 1.0

if (Control == 'K_e') Data = AllKeffDataAllSets[c(1, 2, 3, 4), ]    # CHANGE
if (Control == 'K_e_p') Data = AllKeffDataAllSets[c(1, 4, 3, 2), ]    # CHANGE

Data[2, ] = Data[2, ] / K
Data[3, ] = Data[3, ] / K
Data[4, ] = Data[4, ] / K

AggregRes = ComputeDataAggregates(Data, P_min, P_max, Ke_min, Ke_max, 
																				P_resol, Ke_resol)

Input_matrix_indices = AggregRes$Input_matrix_indices
P_Segs = AggregRes$X_Segs
Ke_Segs = AggregRes$Y_Segs

Num_P_Segs = length(P_Segs) - 1
Num_Ke_Segs = length(Ke_Segs) - 1

# Example: (0.1, 0.4] -- 0.1 is not included, 0.3 is included, 0.4 is included
# Thus, if P is included in the bin (X, Y], then P > X & P <= Y. 
# We use the following condition instead, which makes programming easier: P > X & !P > Y

NumTrimSegs = sum(MinP > P_Segs) * Num_Ke_Segs
NumAllSegsUptoMax = sum(MaxP > P_Segs) * Num_Ke_Segs

KeepSegsIdx = NULL

if (NumTrimSegs < NumAllSegsUptoMax) KeepSegsIdx = (NumTrimSegs + 1) : NumAllSegsUptoMax 

SimData = list()
SimDataIdx = 1

cat(paste('Number of Segs =', length(KeepSegsIdx), '\n'))

if (! is.null(KeepSegsIdx)) {
	
	for (s in KeepSegsIdx) {
		
		SegDataColIds = Input_matrix_indices[[s]]
		
		if (all(SegDataColIds > 0)) {
			
			if (length(SegDataColIds) < 15) next
			
			DataSubset = matrix(Data[ , SegDataColIds], nrow = nrow(Data))
			
			Funcs = matrix(AllFuncsAllSets[ , SegDataColIds], nrow = 2 ^ K)
			
			if (Control == 'K_e') {
				
				SimData[[SimDataIdx]] = list(Funcs = Funcs, P = DataSubset[1, ], K_e = DataSubset[2, ],
															   K_s = DataSubset[3, ], K_e_p = DataSubset[4, ])
				
			}
			
			if (Control == 'K_e_p') {
								
				SimData[[SimDataIdx]] = list(Funcs = Funcs, P = DataSubset[1, ], K_e_p = DataSubset[2, ],
																K_s = DataSubset[3, ], K_e = DataSubset[4, ])    # CHANGE
				
			}
			
			SimDataIdx = SimDataIdx + 1
			
		}
		
	}
	
}

if (Control == 'K_e') fname = paste(dir,'SimDataK',K,'P',MinP,'to',MaxP,'K_e_Norm.Rdata',sep='')
if (Control == 'K_e_p') fname = paste(dir,'SimDataK',K,'P',MinP,'to',MaxP,'K_e_p_Norm.Rdata',sep='')

save(SimData, file = fname)

# Sanity check
# i = sample(length(SimData), 1)
# print(max(SimData[[i]]$K_e_p) - min(SimData[[i]]$K_e_p))
# print(c(min(SimData[[i]]$P), max(SimData[[i]]$P)))
# print(ncol(SimData[[i]]$Funcs))
# print(max(SimData[[i]]$K_e_p) - min(SimData[[i]]$K_e_p))

# # A better sanity check
# Control = 'K_e'
# dir = './Data/'
# MinP = 0
# MaxP = 0.26
# load(file = paste(dir,'SimDataK',K,'P',MinP,'to',MaxP,'K_e_Norm.Rdata',sep=''))  # 'SimData'
# load(file=paste('./Data/PlotDataDFK',K,Control,'ByP_Raw_Freqs.Rdata',sep=''))  # 'PlotDataDF'
# NumSamps1 = sapply(SimData, function(s) ncol(s$Funcs))
# NumSamps2 = PlotDataDF[ , 3]
# NumSamps2 = NumSamps2[NumSamps2 >= 15]
# print(all(NumSamps1 == NumSamps2))

























