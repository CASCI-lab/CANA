args = commandArgs(T)

require(parallel)

source('SimNKEnsembles.R')
source('ComputePerturbationStats.R')

N = 100

K = 10

KeffType = 'K_e'

MinP = args[1]
MaxP = args[2]
PartNum = as.integer(args[3])
NumParts = as.integer(args[4])

NumCores = 32

NumSampleNets = 200
TotalNumInitStates = 1000
NumFlips = c(1, 2, 4, 6, 10)
NumSteps = 10
RecordSteps = c(0, 1, 2, 5, 10)

# NumSampleNets = 2
# TotalNumInitStates = 4
# NumFlips = c(1, 2)
# NumSteps = 2
# RecordSteps = c(0, 1)

load(paste('./Data/SimDataK',K,'P',MinP,'to',MaxP,KeffType,'_Norm.Rdata',sep=''))  # loads into 'SimData'

TotalSize = length(SimData)

PartSize = floor(TotalSize / NumParts)

st = ((PartNum - 1) * PartSize) + 1
nd = st + PartSize - 1

ResidPartSize = TotalSize %% NumParts

if (PartNum == NumParts) nd = nd + ResidPartSize  # Last part

SimDataFilt = SimData[st : nd]

AllNetDynStatsAllNets = mclapply(SimDataFilt, SimNKEnsembles, N, K, NumSampleNets, TotalNumInitStates,
														NumFlips, NumSteps, RecordSteps, mc.cores = NumCores)

save(AllNetDynStatsAllNets, file = paste('./Data/SimResultsK',K,'P',MinP,'to',MaxP,KeffType,'_Norm','_Part_',PartNum,'.Rdata',sep=''))

# AllNetDynStats = SimNKEnsembles(SimData[[41]], N, K, 5, 10, c(1,2), 2, c(0,2))

# print(sapply(AllNetDynStats[[1]], function(s) s$PerturbStats[1, ]))





