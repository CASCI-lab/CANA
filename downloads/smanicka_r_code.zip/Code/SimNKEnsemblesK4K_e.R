args = commandArgs(T)

require(parallel)

source('SimNKEnsembles.R')
source('ComputePerturbationStats.R')

N = 100

K = 4

KeffType = 'K_e'

MinP = args[1]
MaxP = args[2]

NumCores = 32

NumSampleNets = 200
TotalNumInitStates = 1000
NumFlips = c(1, 2, 4, 6, 10)
NumSteps = 10
RecordSteps = c(0, 1, 2, 5, 10)

load(paste('./Data/SimDataK',K,'P',MinP,'to',MaxP,KeffType,'_Norm.Rdata',sep=''))  # loads into 'SimData'

AllNetDynStatsAllNets = mclapply(SimData, SimNKEnsembles, N, K, NumSampleNets, TotalNumInitStates,
														NumFlips, NumSteps, RecordSteps, mc.cores = NumCores)

save(AllNetDynStatsAllNets, file = paste('./Data/SimResultsK',K,'P',MinP,'to',MaxP,KeffType,'_Norm.Rdata',sep=''))

# AllNetDynStats = SimNKEnsembles(SimData[[41]], N, K, 5, 10, c(1,2), 2, c(0,2))

# print(sapply(AllNetDynStats[[1]], function(s) s$PerturbStats[1, ]))